package com.exm.firstsprbootprojs;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class FirstsprbootprojsApplication {

	public static void main(String[] args) {
		SpringApplication.run(FirstsprbootprojsApplication.class, args);
	}

}
